<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b29aa48             |
    |_______________________________________|
*/
 use Pmpr\Custom\TravelFantasy\TravelFantasy; TravelFantasy::symcgieuakksimmu();
