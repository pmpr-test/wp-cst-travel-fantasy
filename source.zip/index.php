<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4be029c5             |
    |_______________________________________|
*/
 use Pmpr\Custom\TravelFantasy\TravelFantasy; TravelFantasy::symcgieuakksimmu();
