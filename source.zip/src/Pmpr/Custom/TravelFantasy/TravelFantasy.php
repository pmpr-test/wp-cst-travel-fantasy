<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f988bd7c8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\CPT\CPT; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\124\x72\x61\x76\145\154\40\106\141\x6e\164\141\163\x79\x20\x43\x75\x73\164\x6f\x6d", PR__CST__TRAVEL_FANTASY); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); } }
