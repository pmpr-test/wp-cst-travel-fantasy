<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a993d02c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
