<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a993d02c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; class CPT extends Container { public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); } }
