<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b29aa48             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\164", [$this, "\143\141\157\145\x69\x75\x71\x61\x69\x71\171\147\155\141\x71\x67"])->qcsmikeggeemccuu("\x70\162\x65\x5f\x67\145\164\x5f\160\157\163\x74", [$this, "\141\x69\x75\157\155\x63\x6d\x6d\171\x67\157\x77\x6f\x73\165\167"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query) { if (($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query()) { $gqgemcmoicmgaqie->set(Constants::uouymeyqasaeckso, [Constants::mswoacegomcucaik, Constants::imywcsggckkcywgk]); } } } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::ocsomysosuqaimuc, Constants::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::qgciomgukmcwscqw, Constants::imywcsggckkcywgk); } }
