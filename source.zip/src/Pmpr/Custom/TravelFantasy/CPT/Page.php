<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f988bd7c8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\151\164", [$this, "\143\141\157\145\x69\x75\161\x61\x69\161\x79\x67\155\141\161\147"])->qcsmikeggeemccuu("\160\162\145\137\147\145\164\137\160\x6f\163\164", [$this, "\141\x69\165\157\155\x63\x6d\x6d\x79\147\x6f\167\x6f\163\x75\167"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query) { if (($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query()) { $gqgemcmoicmgaqie->set(Constants::uouymeyqasaeckso, [Constants::mswoacegomcucaik, Constants::imywcsggckkcywgk]); } } } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::ocsomysosuqaimuc, Constants::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::qgciomgukmcwscqw, Constants::imywcsggckkcywgk); } }
