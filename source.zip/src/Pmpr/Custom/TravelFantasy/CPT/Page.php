<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d80c13c6             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('init', [$this, 'caoeiuqaiqygmaqg'])->qcsmikeggeemccuu('pre_get_post', [$this, 'aiuomcmmygowosuw']); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query) { if (($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query()) { $gqgemcmoicmgaqie->set(Constants::uouymeyqasaeckso, [Constants::mswoacegomcucaik, Constants::imywcsggckkcywgk]); } } } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::ocsomysosuqaimuc, Constants::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::qgciomgukmcwscqw, Constants::imywcsggckkcywgk); } }
